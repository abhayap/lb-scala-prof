check-preconditions

# Exercise 10 > Check Preconditions

- Do you remember the `TODO` comments in `Time`?

- Use the `require` method to verify that `hours` is within 0 and 23

- Use the `require` method to verify that `minutes` is within 0 and 59

- Try it out in the REPL

- Use the `nextExercise` command to move to the next exercise.