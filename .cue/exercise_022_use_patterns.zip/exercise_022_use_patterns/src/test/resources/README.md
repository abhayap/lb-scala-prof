use-patterns

# Exercise 22 > Group exercise: Use Patterns

- Let's use a tuple pattern to get rid of the clumsy tuple field accessors
  in the `stopsAt` method of `JourneyPlanner`

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.