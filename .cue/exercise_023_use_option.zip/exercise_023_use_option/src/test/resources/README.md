use-option

# Exercise 23 > Use Option

- Add a `timeAt` method to `Train`

  - Add a parameter of type `Station`
  - Return an `Option` of `Time`: Return `Some[Time]` if the `Train` stops at
    the station, else return `None`
  - Change `stopsAt` in `JourneyPlanner` in a way that it uses this new method

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.