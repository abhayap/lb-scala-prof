define-a-class

# Exercise 1 > Define a class

In this exercise, we define our first Scala class.

- Create the `Train` class

- Use the `exercises/src/main/scala` source folder of the case study project

- Use `Train.scala` as the file name

- When done, create an instance in the REPL

- Use the `nextExercise` command to move to the next exercise.