use-for-expressions

# Exercise 17 > Use for-expressions

- Add a `stopsAt` method to `JourneyPlanner`

  - Add a `station` parameter of type `Station`
  - Return a `Set` of Tuple2 of `Time` and `Train`
  - Return the stops of all trains at the given station
  - Hint: For the implementation use a for-expression with two generators and
    one filter

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.