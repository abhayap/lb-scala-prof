define-a-field

# Exercise 4 > Define a Field

- Add an immutable `asMinutes` field to `Time`
  - Use `Int` for the type
  - Initialize it with `hours` multiplied by 60 plus `minutes`

- Create a `Time` in the REPL and access `asMinutes`

- Use the `nextExercise` command to move to the next exercise.