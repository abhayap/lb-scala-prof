use-default-arguments

# Exercise 7 > Use Default Arguments

- Modify `Time`'s class parameters `hours` and `minutes` to have default
  values of 0

- Create some `Time`s in the REPL with no arguments for `hours` or `minutes`
  or both

- Use the `nextExercise` command to move to the next exercise.