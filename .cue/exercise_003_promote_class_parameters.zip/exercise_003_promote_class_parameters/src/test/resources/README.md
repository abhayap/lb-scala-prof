promote-class-parameters

# Exercise 3 > Promote class parameters

- Create a `Train` in the REPL and try to access number

- Add (prepend) a kind parameter of type `String` to `Train`

- Promote both parameters of `Train` to immutable fields

- Create a `Train` in the REPL and access kind and number

- Create a `Time` class
  - Add promoted hours and minutes class parameters of type `Int`
  - Add a `TODO` comment: Verify that `hours` is within 0 and 23
  - Add a `TODO` comment: Verify that `minutes` is within 0 and 59

- Create a `Time` in the REPL and access both fields

- Use the `nextExercise` command to move to the next exercise.