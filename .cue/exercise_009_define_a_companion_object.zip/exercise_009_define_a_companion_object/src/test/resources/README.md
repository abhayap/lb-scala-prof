define-a-companion-object

# Exercise 9 > Define a Companion Object

- Create the companion object for `Time`

- Add a `fromMinutes` method

  - Add a minutes parameter of type `Int`

  - Use `Time` for the return type

- Create a `Time` which has normalized values for `hours` and
  `minutes`, i.e. `minutes` has to be within 0 and 59

- Try it out in the REPL

- Use the `nextExercise` command to move to the next exercise.