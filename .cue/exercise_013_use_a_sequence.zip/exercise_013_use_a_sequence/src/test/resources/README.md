use-a-sequence

# Exercise 13 > Use a Sequence

- Create the `Station` case class (add it to `Train.scala`)
  - Add a `name` parameter of type `String`

- Add a `schedule` class parameter to `Train`
  - Use an immutable `Seq` of `Station` for the type
  - Verify that `schedule` contains at least two elements

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.