tests

# Exercise 12 > Group Exercise: Tests

Let's look at the code in the `src/test/scala` source folder and the
`com.lightbend.training.scalatrain package`

- Use the `test` command to verify the solution works as expected.

- Use the `nextExercise` command to move to the next exercise.