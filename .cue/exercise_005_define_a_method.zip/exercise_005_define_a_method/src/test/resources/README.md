define-a-method

# Exercise 5 > Define a Method

- Add a `minus` method to `Time`
  - Add a `that` parameter of type `Time`
  - Use `Int` for the return type
  - Calculate the difference between the two `Time`s in minutes

- Call the method in the REPL

- Use the `nextExercise` command to move to the next exercise.