define-class-parameters

# Exercise 2 > Define class parameters

- Add a class parameter to `Train`
  - Use `number` as name
  - Use `Int` as type

- Quit and restart the REPL

- First try to create a `Train` like before, without arguments

- Then create a `Train` with an appropriate argument

- Use the `nextExercise` command to move to the next exercise.